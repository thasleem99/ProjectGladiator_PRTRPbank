package com.lti.app.repository;

import com.lti.app.pojo.AccountInfo;

public interface AccountInfoRepo {
	public void createAccountInfo(AccountInfo accountInfo);
	public AccountInfo readAccountInfo(String accountNumber);
	public void updateAccountInfo(AccountInfo accountInfo);

}
