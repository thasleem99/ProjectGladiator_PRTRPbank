package com.lti.app.repository;

import com.lti.app.pojo.AdminInfo;

public interface AdminInfoRepo {
	public AdminInfo readAdminByAdminId(String adminId);
	public void createAdmin(AdminInfo adminInfo);

}
