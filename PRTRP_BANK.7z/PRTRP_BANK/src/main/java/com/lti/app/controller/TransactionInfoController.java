package com.lti.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.app.pojo.Beneficiary;
import com.lti.app.pojo.GetTransaction;
import com.lti.app.pojo.Transaction;
import com.lti.app.pojo.TransactionResponse;
import com.lti.app.service.TransactionInfoService;

@RestController
@RequestMapping("/rest/api/transaction")
@CrossOrigin("http://localhost:4200")
public class TransactionInfoController {
	
	@Autowired
	private TransactionInfoService transactionInfoService;
	

	@PostMapping(path = "/addbeneficiary")
	public void addBeneficiary(@RequestBody Beneficiary beneficiary)
	{
		transactionInfoService.addBeneficiary(beneficiary);
	}
	
	@PostMapping(path = "/addtransaction")
	public int addTransaction(@RequestBody Transaction transaction)
	{
		return transactionInfoService.addTransaction(transaction);
	}

	@PostMapping(path = "/checktransaction")
	public TransactionResponse checkTransaction(@RequestBody Transaction transaction)
	{
		return transactionInfoService.checkTransaction(transaction);
	}
	
	@PostMapping(path = "/addsavedpayment")
	public void addSavedPayment(@RequestBody Transaction transaction)
	{
		transactionInfoService.addSavedPayment(transaction);
	}
	
	@PostMapping(path = "/getallsavedpayments")
	public List<Transaction> getAllSavedPayments(@RequestBody String accountNumber)
	{
		return transactionInfoService.getAllSavedPayments(accountNumber);// To be fixed
	}
	
	@PostMapping(path = "/getalltransactions")
	public List<Transaction> getAllTransactions(@RequestBody GetTransaction getTransaction)
	{
		return transactionInfoService.getAllTransactions(getTransaction);
	}
	
	@PostMapping(path = "/getallbeneficiaries")
	public List<Beneficiary> getAllBeneficiaries(@RequestBody String accountNumber)
	{
		return transactionInfoService.getAllBeneficiaries(accountNumber);
	}

}
