package com.lti.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.app.pojo.UserInfo;
import com.lti.app.service.UserInfoService;
 

@RestController
@RequestMapping("/rest/api/userinfo")
@CrossOrigin
public class UserInfoController {

	@Autowired
	private UserInfoService userInfoService;
	
 
	@PostMapping(path = "/createuser")
	public void createNewUser(@RequestBody UserInfo userInfo)
	{
		userInfoService.addUser(userInfo);
	}
	 
	@GetMapping(path = "/getallunverifieduser")
	public List<UserInfo> getAllUnVerifiedUser()
	{
		return userInfoService.getAllUnverifiedUser();
	}
	
 
	@GetMapping(path = "/getallverifieduser")
	public List<UserInfo> getAllVerifiedUser()
	{
		return userInfoService.getAllVerifiedUser();
	}
 
	@GetMapping(path = "/getallrejecteduser")
	public List<UserInfo> getAllRejectedUser()
	{
		return userInfoService.getAllRejectedUser();
	}
	 
	@PostMapping(path = "/verifyuser")
	public void verifyUser(@RequestBody UserInfo userInfo)
	{
		userInfoService.updateStatusCreateCustomer(userInfo);
	}	
}
