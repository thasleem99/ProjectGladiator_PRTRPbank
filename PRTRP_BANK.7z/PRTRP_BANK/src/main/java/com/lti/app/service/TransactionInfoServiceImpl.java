package com.lti.app.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.mail.AfterTransactionMail;
import com.lti.app.pojo.AccountInfo;
import com.lti.app.pojo.Beneficiary;
import com.lti.app.pojo.BeneficiaryInfo;
import com.lti.app.pojo.GetTransaction;
 
import com.lti.app.pojo.SavedPaymentsInfo;
import com.lti.app.pojo.Transaction;
 
import com.lti.app.pojo.TransactionInfo;
import com.lti.app.pojo.TransactionResponse;
import com.lti.app.repository.AccountInfoRepo;
import com.lti.app.repository.BeneficiaryInfoRepo;
import com.lti.app.repository.SavedPaymentsInfoRepo;
import com.lti.app.repository.TransactionInfoRepo;
 

@Service
public class TransactionInfoServiceImpl implements TransactionInfoService {
 
	@Autowired
	private BeneficiaryInfoRepo beneficiaryInfoRepo;
	
	@Autowired
	private AccountInfo accountInfo;
	
	@Autowired
	private AccountInfoRepo accountInfoRepo;
	
	@Autowired
	private TransactionInfoRepo transactionInfoRepo;
	
	@Autowired
	private SavedPaymentsInfoRepo savedPaymentsInfoRepo;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void addBeneficiary(Beneficiary beneficiary)
	{
		accountInfo=accountInfoRepo.readAccountInfo(beneficiary.getCustomerAccountNumber());
		
		BeneficiaryInfo beneficiaryInfo=new BeneficiaryInfo();
		
		beneficiaryInfo.setAccountNumber(accountInfo);
		beneficiaryInfo.setBeneficiaryAccountName(beneficiary.getBeneficiaryName());
		beneficiaryInfo.setBeneficiaryAccountNumber(beneficiary.getBeneficiaryAccountNumber());
		beneficiaryInfo.setBeneficiaryNickName(beneficiary.getBeneficiaryNickName());
		
		beneficiaryInfoRepo.createBeneficiaryInfo(beneficiaryInfo);
	 
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public int addTransaction(Transaction transaction)
	{
		
		
		TransactionInfo transactionInfo1=new TransactionInfo();
		TransactionInfo transactionInfo2=new TransactionInfo();
		
		AccountInfo accountInfo1=accountInfoRepo.readAccountInfo(transaction.getCustomerAccountNumber());
		AccountInfo accountInfo2=accountInfoRepo.readAccountInfo(transaction.getBeneficiaryAccountNumber());
		
		int result=0;
		if(accountInfo1!=null&&accountInfo2!=null)
		{
		
			
				double balance1=accountInfo1.getAccountBalance()-Double.parseDouble(transaction.getAmount());
				double balance2=accountInfo2.getAccountBalance()+Double.parseDouble(transaction.getAmount());
				
				int transactionId1=(int)(Math.random()*100000000);
				int transactionId2=(int)(Math.random()*100000000);
				
				result=transactionId1;
				
				transactionInfo1.setTransactionId(transactionId1);
				transactionInfo2.setTransactionId(transactionId2);
				
				transactionInfo1.setAccountInfo(accountInfo1);
				transactionInfo2.setAccountInfo(accountInfo2);
				
				transactionInfo1.setDebit(Double.parseDouble(transaction.getAmount()));
				transactionInfo2.setCredit(Double.parseDouble(transaction.getAmount()));
				
				transactionInfo1.setBalance(balance1);
				transactionInfo2.setBalance(balance2);
				
				transactionInfo1.setModeOfTransaction(transaction.getModeOfTransaction());
				transactionInfo2.setModeOfTransaction(transaction.getModeOfTransaction());
				
				transactionInfo1.setParticular("Paid To "+accountInfo2.getCustomerName());
				transactionInfo2.setParticular("Received From "+accountInfo1.getCustomerName());
				
				transactionInfo1.setTransactionDate(new Date());
				transactionInfo2.setTransactionDate(new Date());
				
				transactionInfoRepo.createTransaction(transactionInfo1);
				transactionInfoRepo.createTransaction(transactionInfo2);
				
				accountInfo1.setAccountBalance(balance1);
				accountInfo2.setAccountBalance(balance2);
				
				accountInfoRepo.updateAccountInfo(accountInfo1);
				accountInfoRepo.updateAccountInfo(accountInfo2);
				
				String message1="Dear "+accountInfo1.getCustomerName()+",\nA sum of Rs. "+transaction.getAmount()+
						" has been debited from your bank account for making a payment to "+accountInfo2.getCustomerName()
						+".\nPlease Contact us at prtrpbank@gmail.com if the payment was not done by you\n"
						+ "\n\n Thank you for choosing PRTRPBank.\n Have a nice Day!";
				
				String message2="Dear "+accountInfo2.getCustomerName()+",\nA sum of Rs. "+transaction.getAmount()+
						" has been credited into your bank account by "+accountInfo1.getCustomerName()
						+".\n\nFor any queries please Contact us at prtrpbank@gmail.com \n\nHave a nice Day!";
						
				
				try {
					AfterTransactionMail.sendEmail(accountInfo1.getCustomerDetails().getEmailId(), message1);
					AfterTransactionMail.sendEmail(accountInfo2.getCustomerDetails().getEmailId(), message2);
				} 
				
				catch (MessagingException e) 
				{
					
					e.printStackTrace();
				}
				
				
			}
		return result;
		}
			
	

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void addSavedPayment(Transaction transaction)
	{
		AccountInfo accountInfo=accountInfoRepo.readAccountInfo(transaction.getCustomerAccountNumber());
		SavedPaymentsInfo savedPaymentsInfo=new SavedPaymentsInfo();
		
		savedPaymentsInfo.setFromAccountNumber(accountInfo);
		savedPaymentsInfo.setModeOfPayment(transaction.getModeOfTransaction());
		savedPaymentsInfo.setToAccountNumber(transaction.getBeneficiaryAccountNumber());
		savedPaymentsInfo.setTransactionAmount(Double.parseDouble(transaction.getAmount()));
		savedPaymentsInfo.setTransactionDate(transaction.getDateOfPayment());
		
		savedPaymentsInfoRepo.createSavedPayment(savedPaymentsInfo);
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Transaction> getAllSavedPayments(String accountNumber) {
		
		List<SavedPaymentsInfo> savedPaymentsInfo=savedPaymentsInfoRepo.readAllSavedPaymentsByAccountNumber(accountNumber);
		
		List<Transaction> transactions=new ArrayList<>();
		for(SavedPaymentsInfo save:savedPaymentsInfo )
		{
			Transaction transaction=new Transaction();
			transaction.setAmount(""+save.getTransactionAmount());
			transaction.setBeneficiaryAccountNumber(save.getToAccountNumber());
			transaction.setDateOfPayment(save.getTransactionDate());
			transaction.setModeOfTransaction(save.getModeOfPayment());
			transaction.setCustomerAccountNumber(accountNumber);
			
			transactions.add(transaction);
		
		}		
		return transactions;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public TransactionResponse checkTransaction(Transaction transaction) {
		
		
		List<BeneficiaryInfo> beneficiaryInfos=new ArrayList<>();
		AccountInfo accountInfo1=accountInfoRepo.readAccountInfo(transaction.getCustomerAccountNumber());
		TransactionResponse transactionResponse=new TransactionResponse();
		
		beneficiaryInfos=beneficiaryInfoRepo.readAllBeneficiaries(transaction.getCustomerAccountNumber());
		int flag=0;
		for(BeneficiaryInfo b:beneficiaryInfos)
		{
			if(b.getBeneficiaryAccountNumber().equals(transaction.getBeneficiaryAccountNumber()))
			{
				flag=1;
				break;
			}
		}
		double actualBalance=accountInfo1.getAccountBalance();
		
		double transactionAmount=Double.parseDouble(transaction.getAmount());
		
		if(flag==0)
		{
			transactionResponse.setResponse("BENEFICIARY DOESNOT EXIST");
		}
		else if(actualBalance<transactionAmount)
		{
			transactionResponse.setResponse("INSUFFICIENT ACCOUNT BALANCE");
		}
			
		else
		{
			transactionResponse.setResponse("OK");
		}
		
		return transactionResponse;
	
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Transaction> getAllTransactions(GetTransaction getTransaction) {
		
		List<Transaction> transactions=new ArrayList<>();
		
		List<TransactionInfo> transactionInfos=transactionInfoRepo.readTransactionsBetweenDate(getTransaction.getAccountNumber(), getTransaction.getFromDate(), getTransaction.getToDate());
		for(TransactionInfo transactionInfo:transactionInfos)
		{
			Transaction transaction=new Transaction();
			if(transactionInfo.getCredit()==0)
			{
				transaction.setDebitOrCredit("DEBIT");
				transaction.setAmount(transactionInfo.getDebit()+"");
			}
			else
			{
				transaction.setDebitOrCredit("CREDIT");
				transaction.setAmount(transactionInfo.getCredit()+"");
			}
			
			transaction.setBeneficiaryAccountNumber(transactionInfo.getParticular());
			transaction.setDateOfPayment(transactionInfo.getTransactionDate());
			transaction.setModeOfTransaction(transactionInfo.getModeOfTransaction());
			
			transactions.add(transaction);
			
		}
		
		return transactions;
	
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Beneficiary> getAllBeneficiaries(String accountNumber) 
	{
		List<Beneficiary> beneficiarys=new ArrayList<>();
		List<BeneficiaryInfo> beneficiaryInfos=beneficiaryInfoRepo.readAllBeneficiaries(accountNumber);
		for(BeneficiaryInfo beneficiaryInfo:beneficiaryInfos)
		{
			Beneficiary beneficiary =new Beneficiary();
			beneficiary.setBeneficiaryAccountNumber(beneficiaryInfo.getBeneficiaryAccountNumber());
			beneficiary.setBeneficiaryName(beneficiaryInfo.getBeneficiaryAccountName());
			beneficiary.setBeneficiaryNickName(beneficiaryInfo.getBeneficiaryNickName());
			
			beneficiarys.add(beneficiary);
			
		}
		return beneficiarys;
	}
}



 


