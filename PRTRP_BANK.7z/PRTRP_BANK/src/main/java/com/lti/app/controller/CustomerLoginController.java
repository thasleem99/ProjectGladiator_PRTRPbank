package com.lti.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.app.pojo.ChangeLoginPassword;
import com.lti.app.pojo.InternetBankingRegistration;
import com.lti.app.pojo.Login;
import com.lti.app.service.LoginInfoService;
 

@RestController
@RequestMapping("/rest/api/customerlogin")
@CrossOrigin("http://localhost:4200")
public class CustomerLoginController {

	@Autowired
	private LoginInfoService loginInfoService;
	
	@PostMapping(path = "/getlogin")
	public Login getLogin(@RequestBody String internetBankingId)
	{
		Login login= loginInfoService.getLoginInfo(internetBankingId);
		return login;
	}
	
	@PostMapping(path="/createlogin")
	public String createLoginInfo(@RequestBody InternetBankingRegistration internetBankingRegistratio)
	{
		return loginInfoService.addLoginInfo(internetBankingRegistratio);
	}
	
	@PostMapping(path = "/unlockaccount")
	public void unlockAccount(@RequestBody String internetBankingId)
	{
		loginInfoService.unlockLoginInfo(internetBankingId);
	}

	@PostMapping(path = "/changeloginpassword")
	public void changeLoginPassword(@RequestBody ChangeLoginPassword changeLoginPassword)
	{
		loginInfoService.updateLoginPassword(changeLoginPassword);
	}
	
	@PostMapping(path = "/forgotpassword")
	public String forgotLoginPassword(@RequestBody String internetBankingId)
	{
		return loginInfoService.forgotLoginPassword(internetBankingId);
	}
 
	@PostMapping(path = "/forgotid")
	public String forgotInternetBankingId(@RequestBody String accountNumber)
	{
		return loginInfoService.forgotInternetBankingId(accountNumber);
	}
	 
	@PostMapping(path = "/sendid")
	public void sendInternetBankingId(@RequestBody String accountNumber)
	{
		loginInfoService.sendInternetBankingId(accountNumber);
	}
	
	
	
	
}
