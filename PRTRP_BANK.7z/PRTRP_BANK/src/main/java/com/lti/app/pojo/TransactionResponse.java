package com.lti.app.pojo;

public class TransactionResponse {
	private String response;

	public TransactionResponse(String response) {
		super();
		this.response = response;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public TransactionResponse() {
		super();
	}

	@Override
	public String toString() {
		return "TransactionResponseDTO [response=" + response + "]";
	}
	
	
}
