package com.lti.app.service;

import com.lti.app.pojo.AdminInfo;
import com.lti.app.pojo.Login;

public interface AdminInfoService {
	public Login readAdminInfo(String adminId);
	public void createAdminInfo(AdminInfo adminInfo);

}
