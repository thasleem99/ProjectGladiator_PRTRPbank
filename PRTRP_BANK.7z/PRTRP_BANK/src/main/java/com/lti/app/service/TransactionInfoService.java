package com.lti.app.service;

import java.util.List;

import com.lti.app.pojo.Beneficiary;
import com.lti.app.pojo.GetTransaction;
import com.lti.app.pojo.Transaction;
import com.lti.app.pojo.TransactionResponse;

 

public interface TransactionInfoService {
	public void addBeneficiary(Beneficiary beneficiary);
	public int addTransaction(Transaction transaction);
	public TransactionResponse checkTransaction(Transaction transaction);
	public void addSavedPayment(Transaction transaction);
	public List<Transaction> getAllSavedPayments(String accountNumber);
	public List<Transaction> getAllTransactions(GetTransaction getTransaction);
	public List<Beneficiary> getAllBeneficiaries(String accountNumber);

}
