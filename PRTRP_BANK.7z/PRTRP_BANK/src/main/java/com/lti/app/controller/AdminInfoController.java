package com.lti.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.app.pojo.AdminInfo;
import com.lti.app.pojo.Login;
import com.lti.app.service.AdminInfoService;

 

@RestController
@RequestMapping("/rest/api/admininfo")
@CrossOrigin("http://localhost:4200")
public class AdminInfoController {

	@Autowired
	private AdminInfoService adminInfoService;
	
	@PostMapping(path="/createadmin")
	public void createAdmin(@RequestBody AdminInfo adminInfo)
	{
		adminInfoService.createAdminInfo(adminInfo);
	}
	@PostMapping(path="/adminid")
	public Login getAdmin(@RequestBody String adminId)
	{
		 return adminInfoService.readAdminInfo(adminId);
		 
	}
	
}
