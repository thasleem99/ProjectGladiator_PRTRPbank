package com.lti.app.pojo;

public class ChangeTransactionPassword {
    @Override
	public String toString() {
		return "ChangeTransactionPassword [accountNumber=" + accountNumber + ", transactionPassword="
				+ transactionPassword + "]";
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	private String accountNumber;
	
	private String transactionPassword;

	public ChangeTransactionPassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
