package com.lti.app.repository;

import com.lti.app.pojo.LoginInfo;

public interface LoginInfoRepo {
	public LoginInfo readLoginInfo(String internetBankingId);
	public void updateLogininfo(LoginInfo loginInfo);
	public void updateLoginPassword(String newloginPassword,String internetBankingId);
	public void createInternetBanking(LoginInfo loginInfo);

}
