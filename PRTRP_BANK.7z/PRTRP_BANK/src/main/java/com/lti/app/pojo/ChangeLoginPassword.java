package com.lti.app.pojo;

public class ChangeLoginPassword {
	@Override
	public String toString() {
		return "ChangeLoginPassword [internetBankingId=" + internetBankingId + ", loginPassword=" + loginPassword + "]";
	}
	public String getInternetBankingId() {
		return internetBankingId;
	}
	public void setInternetBankingId(String internetBankingId) {
		this.internetBankingId = internetBankingId;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	private String internetBankingId;
	private String loginPassword;
	public ChangeLoginPassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
