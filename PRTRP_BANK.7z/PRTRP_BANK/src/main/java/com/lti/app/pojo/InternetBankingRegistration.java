package com.lti.app.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class InternetBankingRegistration {
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getConfirmLoginPassword() {
		return confirmLoginPassword;
	}
	public void setConfirmLoginPassword(String confirmLoginPassword) {
		this.confirmLoginPassword = confirmLoginPassword;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public String getConfirmTransactionPassword() {
		return confirmTransactionPassword;
	}
	public void setConfirmTransactionPassword(String confirmTransactionPassword) {
		this.confirmTransactionPassword = confirmTransactionPassword;
	}
	@Override
	public String toString() {
		return "InteretBankingRegistration [accountNumber=" + accountNumber + ", loginPassword=" + loginPassword
				+ ", confirmLoginPassword=" + confirmLoginPassword + ", transactionPassword=" + transactionPassword
				+ ", confirmTransactionPassword=" + confirmTransactionPassword + "]";
	}
	private String accountNumber;
	private String loginPassword;
	private String confirmLoginPassword;
	private String transactionPassword;
	private String confirmTransactionPassword;
	public InternetBankingRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
