package com.lti.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.pojo.AccountInfo;
import com.lti.app.pojo.ChangeTransactionPassword;
import com.lti.app.repository.AccountInfoRepo;
 

@Service
public class AccountInfoServiceImpl implements AccountInfoService
{
	@Autowired
	private AccountInfoRepo accountInfoDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public double getAccountBalance(String accountNumber)
	{
		AccountInfo accountInfo=accountInfoDao.readAccountInfo(accountNumber);
		return accountInfo.getAccountBalance();
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateTransactionPassword(ChangeTransactionPassword changeTransactionPassword)
	{
		AccountInfo accountInfo=accountInfoDao.readAccountInfo(changeTransactionPassword.getAccountNumber());
		accountInfo.setTransactionPassword(changeTransactionPassword.getTransactionPassword());
		accountInfoDao.updateAccountInfo(accountInfo);
		
	}
	
}
