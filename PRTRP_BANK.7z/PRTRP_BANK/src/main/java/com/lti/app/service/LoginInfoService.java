package com.lti.app.service;

import com.lti.app.pojo.ChangeLoginPassword;
import com.lti.app.pojo.InternetBankingRegistration;
import com.lti.app.pojo.Login;

public interface LoginInfoService {
	public Login getLoginInfo(String internetBankingId);
	public String addLoginInfo(InternetBankingRegistration internetBankingRegistration);
	public void unlockLoginInfo(String internetBankingId);
	public void updateLoginPassword(ChangeLoginPassword changeLoginPassword);
	public String forgotLoginPassword(String internetBankingId);
	public String forgotInternetBankingId(String accountNumber);
	public void sendInternetBankingId(String accountNumber);

}
