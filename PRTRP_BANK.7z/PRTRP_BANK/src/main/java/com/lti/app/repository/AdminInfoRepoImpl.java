package com.lti.app.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.pojo.AdminInfo;
 

@Repository
public class AdminInfoRepoImpl implements AdminInfoRepo {

	@PersistenceContext
	EntityManager entityManager=null;
	
	public AdminInfoRepoImpl() {
		
	}
	
	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public AdminInfo readAdminByAdminId(String adminId) {
		AdminInfo admin=entityManager.find(AdminInfo.class,adminId);
		return admin;
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public void createAdmin(AdminInfo adminInfo) {
		
		entityManager.persist(adminInfo);
	}

}