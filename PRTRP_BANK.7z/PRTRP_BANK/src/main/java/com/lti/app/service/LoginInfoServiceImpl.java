package com.lti.app.service;

import java.util.Date;
import java.util.Random;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.mail.ForgotInternetBankingIdMail;
import com.lti.app.mail.ForgotLoginPasswordMail;
import com.lti.app.mail.LoginAccountActivationThroughOTPMail;
import com.lti.app.mail.SendInternetBankingIdMail;
import com.lti.app.pojo.AccountInfo;
import com.lti.app.pojo.ChangeLoginPassword;
import com.lti.app.pojo.InternetBankingRegistration;
import com.lti.app.pojo.Login;
import com.lti.app.pojo.LoginInfo;
import com.lti.app.repository.AccountInfoRepo;
import com.lti.app.repository.LoginInfoRepo;
  
@Service
public class LoginInfoServiceImpl implements LoginInfoService {

	@Autowired
	private Login login;
	
	@Autowired
	private AccountInfoRepo accountInfoRepo;
	
	@Autowired
	private AccountInfo accountInfo;
	
	@Autowired
	private LoginInfo loginInfo;
	
	@Autowired
	private LoginInfoRepo loginInfoRepo;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Login getLoginInfo(String internetBankingId) {
		
		loginInfo=loginInfoRepo.readLoginInfo(internetBankingId);
		
		loginInfo.setLastLogin(new Date());
		
		
		loginInfoRepo.updateLogininfo(loginInfo);
		
		
		login.setInternetBankingId(loginInfo.getInternetBankingId());
		login.setLoginPassword(loginInfo.getLoginPassword());
		login.setAccountNumber(loginInfo.getAccountInfo().getAccountNumber());
		login.setCustomerName(loginInfo.getAccountInfo().getCustomerName());
		login.setAccountBalance(""+loginInfo.getAccountInfo().getAccountBalance());
		login.setTransactionPassword(loginInfo.getAccountInfo().getTransactionPassword());
		
		return login;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public String addLoginInfo(InternetBankingRegistration internetBankingRegistration)
	{
		accountInfo=accountInfoRepo.readAccountInfo(internetBankingRegistration.getAccountNumber());
		accountInfo.setTransactionPassword(internetBankingRegistration.getTransactionPassword());
		
		loginInfo.setAccountInfo(accountInfo);
		loginInfo.setEmailId(accountInfo.getCustomerDetails().getEmailId());
		
				
		Random random=new Random();
		int randomNum=(int)(random.nextDouble()*100000000);
		String internetBankingId="68"+randomNum;
		loginInfo.setInternetBankingId(internetBankingId);
		
		loginInfo.setLastLogin(null);
		loginInfo.setLocked(true);
		loginInfo.setLoginPassword(internetBankingRegistration.getLoginPassword());
		loginInfo.setMobileNumber(accountInfo.getCustomerDetails().getMobileNumber());
		loginInfo.setNumberOfAttemptedLogin(0);
		
		accountInfo.setLoginInfo(loginInfo);
		
		loginInfoRepo.createInternetBanking(loginInfo);
		accountInfoRepo.updateAccountInfo(accountInfo);
		
		
		int otp=(int)(Math.random()*10000);
		String otpMessage="Dear "+accountInfo.getCustomerName()+
				",\nYour new Internet Banking ID has been created.\n\nInternet Banking ID: "+
				internetBankingId+".\n\nYour 4 Digit OTP for verification :"+otp;
		try
		{
			LoginAccountActivationThroughOTPMail.sendEmail(accountInfo.getCustomerDetails().getEmailId(), otpMessage);
		} 
		
		catch (MessagingException e) 
		{
			
			e.printStackTrace();
		}
		
		return ""+otp;
		
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void unlockLoginInfo(String internetBankingId)
	{
		LoginInfo loginInfo=loginInfoRepo.readLoginInfo(internetBankingId);
		loginInfo.setLocked(false);
		loginInfoRepo.updateLogininfo(loginInfo);
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateLoginPassword(ChangeLoginPassword changeLoginPassword)
	{
		loginInfo=loginInfoRepo.readLoginInfo(changeLoginPassword.getInternetBankingId());
		loginInfo.setLoginPassword(changeLoginPassword.getLoginPassword());
		loginInfoRepo.updateLogininfo(loginInfo);
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public String forgotLoginPassword(String internetBankingId) {
		LoginInfo loginInfo=loginInfoRepo.readLoginInfo(internetBankingId);
		int randomotp=(int)(Math.random()*10000);
		String otp=""+randomotp;
		String message="Dear "+loginInfo.getAccountInfo().getCustomerName()+
				" ,\nYour OTP for setting a new Login password is "+otp+"\n\nHave a nice day!!";
		
		try 
		{
			ForgotLoginPasswordMail.sendEmail(loginInfo.getEmailId(), message);
		} 
		
		catch (MessagingException e) {
		
			e.printStackTrace();
		}
		
		return otp;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public String forgotInternetBankingId(String accountNumber) {
		accountInfo=accountInfoRepo.readAccountInfo(accountNumber);
		int randomotp=(int)(Math.random()*10000);
		String otp=""+randomotp;
		String message="Dear "+accountInfo.getCustomerName()+
				" ,\nYour OTP for retrieving your Internet Banking ID is "+otp+"\n\nHave a nice day!!";
		
		try
		{
			
			ForgotInternetBankingIdMail.sendEmail(accountInfo.getCustomerDetails().getEmailId(), message);
		} 
		catch (MessagingException e) {
			
			e.printStackTrace();
		}
		return otp;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void sendInternetBankingId(String accountNumber) {
		accountInfo=accountInfoRepo.readAccountInfo(accountNumber);
		String message="Dear "+accountInfo.getCustomerName()+",\n"+
		"Your Otp Verification was successful.\nYour Internet Banking Id is: "
				+accountInfo.getLoginInfo().getInternetBankingId()+"\nHave a nice day!";
		
		try
		{
			SendInternetBankingIdMail.sendEmail(accountInfo.getCustomerDetails().getEmailId(), message);
		} 
		catch (MessagingException e)
		{
			
			e.printStackTrace();
		}
		
		
	}

}
