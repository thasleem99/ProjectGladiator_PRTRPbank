package com.lti.app.repository;

import java.util.List;

import com.lti.app.pojo.SavedPaymentsInfo;

public interface SavedPaymentsInfoRepo {
	public void createSavedPayment(SavedPaymentsInfo savedPayment);
	public List<SavedPaymentsInfo> readAllSavedPaymentsByAccountNumber(String accountNumber);
	public int deleteSavedPayment(String serialNumber);

}
