package com.lti.app.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.pojo.Beneficiary;
import com.lti.app.pojo.BeneficiaryInfo;

 
@Repository
public class BeneficiaryInfoRepoImpl implements BeneficiaryInfoRepo {
	
	@PersistenceContext
	EntityManager entityManager=null;
	
	public BeneficiaryInfoRepoImpl() {
		
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public void createBeneficiaryInfo(BeneficiaryInfo beneficiary) {
		entityManager.persist(beneficiary);
		
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	
	public int deleteBeneficiaryInfo(String customerAccountNumber, String beneficiaryAccountNumber) {
		String jpql="Delete b from BeneficiaryInfo b where (b.beneficiaryAccountNumber=:beneficiaryAccountNumber and b.accountNumber=:customerAccountNumber) ";
		TypedQuery<Beneficiary> tQuery=entityManager.createQuery(jpql, Beneficiary.class);
		tQuery.setParameter("beneficiaryAccountNumber",beneficiaryAccountNumber);
		tQuery.setParameter("customerAccountNumber", customerAccountNumber);
		int result=tQuery.executeUpdate();
		return result;
				
	}

	@Override
	@Transactional(propagation = Propagation.MANDATORY)
	public List<BeneficiaryInfo> readAllBeneficiaries(String customerAccountNumber) {
		
		String jpql="Select b from BeneficiaryInfo b where  b.accountNumber.accountNumber=:customerAccountNumber";
		TypedQuery<BeneficiaryInfo> tQuery=entityManager.createQuery(jpql, BeneficiaryInfo.class);
		tQuery.setParameter("customerAccountNumber", customerAccountNumber);
		List<BeneficiaryInfo> beneficiaries=tQuery.getResultList();
		return beneficiaries;
	}

}
