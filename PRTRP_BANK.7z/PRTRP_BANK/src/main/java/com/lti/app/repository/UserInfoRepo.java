package com.lti.app.repository;

import java.util.List;

import com.lti.app.pojo.UserInfo;

public interface UserInfoRepo {
	public void createUser(UserInfo userDetails);
	public List<UserInfo> readAllUnVerifiedUser();
	public List<UserInfo> readAllVerifiedUser();
	public List<UserInfo> readAllRejectedUser();
	public void updateUserStatus(UserInfo userInfo);
	public UserInfo getUserByServiceNumber(String serviceNumber);

}
