package com.lti.app.pojo;

public class OTPVerification {
	@Override
	public String toString() {
		return "OTPVerification [internetBankingId=" + internetBankingId + ", otp=" + otp + "]";
	}
	public String getInternetBankingId() {
		return internetBankingId;
	}
	public void setInternetBankingId(String internetBankingId) {
		this.internetBankingId = internetBankingId;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	private String internetBankingId;
	private String otp;
	public OTPVerification() {
		super();
		// TODO Auto-generated constructor stub
	}
}
