package com.lti.app.repository;

import com.lti.app.pojo.CustomerInfo;

public interface CustomerInfoRepo {
	public CustomerInfo readCustomerInfo(String customerId);
	public void createCustomerInfo(CustomerInfo customerInfo);
	public void updateMobileNumber(String customerId,String mobileNumber);

}
