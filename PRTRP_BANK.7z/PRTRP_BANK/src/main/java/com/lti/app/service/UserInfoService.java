package com.lti.app.service;

import java.util.List;

import com.lti.app.pojo.UserInfo;
 

public interface UserInfoService {
public void addUser(UserInfo userInfo);
	
	public void updateStatusCreateCustomer(UserInfo userInfo);
	
	public List<UserInfo> getAllUnverifiedUser();
	
	public List<UserInfo> getAllVerifiedUser();
	
	public List<UserInfo> getAllRejectedUser();

}
