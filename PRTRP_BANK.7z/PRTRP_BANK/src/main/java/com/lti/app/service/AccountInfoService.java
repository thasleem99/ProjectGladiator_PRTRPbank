package com.lti.app.service;

import com.lti.app.pojo.ChangeTransactionPassword;

public interface AccountInfoService {
	public double getAccountBalance(String accountNumber);
	public void updateTransactionPassword(ChangeTransactionPassword changeTransactionPassword);

}
