package com.lti.app.repository;

import java.util.List;

import com.lti.app.pojo.Beneficiary;
import com.lti.app.pojo.BeneficiaryInfo;


public interface BeneficiaryInfoRepo {

	public void createBeneficiaryInfo(BeneficiaryInfo beneficiary);
	public int deleteBeneficiaryInfo(String customerAccountNumber,String beneficiaryAccountNumber);
	public List<BeneficiaryInfo> readAllBeneficiaries(String customerAccountNumber);

}
