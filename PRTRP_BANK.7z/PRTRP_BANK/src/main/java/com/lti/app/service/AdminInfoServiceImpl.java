package com.lti.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.pojo.AdminInfo;
import com.lti.app.pojo.Login;
import com.lti.app.repository.AdminInfoRepo;
 

@Service
public class AdminInfoServiceImpl implements AdminInfoService {

	@Autowired
	private AdminInfoRepo adminInfoDao;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public Login readAdminInfo(String adminId) 
	{
		AdminInfo adminInfo=adminInfoDao.readAdminByAdminId(adminId);
		Login login=new Login();
		login.setInternetBankingId(adminInfo.getAdminId());
		login.setLoginPassword(adminInfo.getAdminPassword());
		
		return login;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void createAdminInfo(AdminInfo adminInfo)
	{
		adminInfoDao.createAdmin(adminInfo);
		
	}

}
